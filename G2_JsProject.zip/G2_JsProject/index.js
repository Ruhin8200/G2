$(document).ready(function () {
  $("#slider>li:gt(0)").hide();
  setInterval(function () {
    $("#slider > li:first")
      .fadeOut(1000)
      .next()
      .fadeIn(1000)
      .end()
      .appendTo("#slider");
  }, 2000);
});

window.onscroll = function () {
  var goUpArrow = document.querySelector(".go-up-arrow");
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    goUpArrow.style.display = "block";
  } else {
    goUpArrow.style.display = "none";
  }
};

function scrollToTop() {
  var scrollOptions = {
    top: 0,
    behavior: "smooth",
  };
  window.scrollTo(scrollOptions);
}

const validateForm = () => {
  const emailInput = document.getElementById("email");
  const errorMessage = document.getElementById("error-msg");
  const successMessage = document.getElementById("success-msg");
  const email = emailInput.value.trim();

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (email === "") {
    errorMessage.innerText = "Email address is required";
    return false;
  } else if (!emailPattern.test(email)) {
    errorMessage.innerText = "Invalid email address";
    successMessage.innerText = "";
    return false;
  } else {
    errorMessage.innerText = "";
    successMessage.innerText = "Subscribed!";
    emailInput.value = "";
    return true;
  }
};

document
  .getElementById("send-icon")
  .addEventListener("click", function (event) {
    if (!validateForm()) {
      event.preventDefault();
    }
  });
